# Music Phone - Forge 1.20.1

## الرفع على GitHub
1. ارفع كل الملفات في جذر المستودع.
2. ملف الـ YML هنا بالضبط:  .github/workflows/build.yml
3. Actions يبني المود. الـ Jar في Artifacts (musicphone-jar).

## استبدال الأغاني (ogg، نفس الاسم)
src/main/resources/assets/musicphone/sounds/private/private_one.ogg  (two, three)
src/main/resources/assets/musicphone/sounds/server/server_one.ogg    (two, three)
- المدة تُقرأ تلقائياً. الحد الأقصى 8 دقائق.
- تحويل: ffmpeg -i input.mp3 -c:a libvorbis -q:a 4 song.ogg

## خلفية الهاتف (PNG)
src/main/resources/assets/musicphone/textures/gui/phone_bg.png

## أسماء الأغاني
assets/musicphone/lang/en_us.json و ar_sa.json   (musicphone.song.private_one ...)

## الأوامر
- /musicphone admin  الهاتف الإداري (OP فقط، وفي العالم الفردي Cheats مفعّلة)
- /musicphone guide  كتاب التعليمات

## الوصفات
- الهاتف: حديد x6 + لوح زجاج + ريدستون  (III / IGI / IRI)
- الكتاب: كتاب + ريدستون
