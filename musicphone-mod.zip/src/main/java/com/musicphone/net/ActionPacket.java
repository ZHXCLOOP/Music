package com.musicphone.net;

import com.musicphone.PhoneManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** أدمن -> سيرفر: تشغيل / إيقاف / نمط أغاني السيرفر. Admin -> server: play / stop / mode of SERVER music. */
public class ActionPacket {

    public static final byte PLAY = 0, STOP = 1, MODE = 2;

    public final byte type;
    public final int value;

    public ActionPacket(byte type, int value) {
        this.type = type;
        this.value = value;
    }

    public static void encode(ActionPacket m, FriendlyByteBuf buf) {
        buf.writeByte(m.type);
        buf.writeInt(m.value);
    }

    public static ActionPacket decode(FriendlyByteBuf buf) {
        return new ActionPacket(buf.readByte(), buf.readInt());
    }

    public static void handle(ActionPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer p = c.getSender();
            if (p != null && PhoneManager.canControl(p)) PhoneManager.handle(m.type, m.value);
        });
        c.setPacketHandled(true);
    }
}
