package com.musicphone.net;

import com.musicphone.client.ClientMusic;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** سيرفر -> كل اللاعبين: الأغنية الحالية والنمط. Server -> all players: current song and mode. */
public class StatePacket {

    public final int current;   // -1 = متوقف
    public final int mode;
    public final int serial;    // يتغير مع كل بداية أغنية

    public StatePacket(int current, int mode, int serial) {
        this.current = current;
        this.mode = mode;
        this.serial = serial;
    }

    public static void encode(StatePacket m, FriendlyByteBuf buf) {
        buf.writeInt(m.current);
        buf.writeByte(m.mode);
        buf.writeInt(m.serial);
    }

    public static StatePacket decode(FriendlyByteBuf buf) {
        return new StatePacket(buf.readInt(), buf.readByte(), buf.readInt());
    }

    public static void handle(StatePacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientMusic.onState(m)));
        c.setPacketHandled(true);
    }
}
