package com.musicphone;

import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = MusicPhoneMod.MOD_ID)
public final class ServerEvents {

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase == TickEvent.Phase.END) PhoneManager.tick();
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) {
        ModCommands.register(e.getDispatcher());
    }

    @SubscribeEvent
    public static void onStarting(ServerStartingEvent e) {
        PhoneManager.reset();
    }

    @SubscribeEvent
    public static void onStopped(ServerStoppedEvent e) {
        PhoneManager.reset();
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) PhoneManager.sendTo(sp);
    }

    private ServerEvents() {}
}
