package com.musicphone;

/** يقرأ مدة ملف Ogg Vorbis بدون فك ترميزه. Reads Ogg Vorbis length without decoding. */
final class OggDuration {

    static double seconds(byte[] d) {
        if (d.length < 64 || d[0] != 'O' || d[1] != 'g' || d[2] != 'g' || d[3] != 'S') {
            throw new IllegalArgumentException("not an ogg file");
        }
        int segs = d[26] & 0xFF;
        int p = 27 + segs;                       // first packet = vorbis identification header
        int rate = (d[p + 12] & 0xFF) | (d[p + 13] & 0xFF) << 8 | (d[p + 14] & 0xFF) << 16 | (d[p + 15] & 0xFF) << 24;
        if (rate <= 0) throw new IllegalArgumentException("bad sample rate");

        for (int i = d.length - 14; i >= 0; i--) {   // last page holds total samples
            if (d[i] == 'O' && d[i + 1] == 'g' && d[i + 2] == 'g' && d[i + 3] == 'S') {
                long granule = 0;
                for (int b = 7; b >= 0; b--) granule = (granule << 8) | (d[i + 6 + b] & 0xFF);
                if (granule > 0) return (double) granule / rate;
            }
        }
        throw new IllegalArgumentException("no granule position");
    }

    private OggDuration() {}
}
