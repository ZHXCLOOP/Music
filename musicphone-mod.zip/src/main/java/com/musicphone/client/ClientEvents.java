package com.musicphone.client;

import com.musicphone.MusicPhoneMod;
import net.minecraft.sounds.SoundSource;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.sound.PlaySoundEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = MusicPhoneMod.MOD_ID, value = Dist.CLIENT)
public final class ClientEvents {

    /** يكتم موسيقى ماينكرافت الخلفية فقط أثناء تشغيل الهاتف. Mutes vanilla music only while the phone plays. */
    @SubscribeEvent
    public static void onPlaySound(PlaySoundEvent e) {
        if (ClientMusic.isPlaying() && e.getSound() != null && e.getSound().getSource() == SoundSource.MUSIC) {
            e.setSound(null);
        }
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase == TickEvent.Phase.END) ClientMusic.tick();
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        ClientMusic.reset();
    }

    private ClientEvents() {}
}
