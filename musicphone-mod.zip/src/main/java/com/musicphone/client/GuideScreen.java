package com.musicphone.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

import java.util.List;

/** كتاب التعليمات / The instruction book. Text comes from the lang files: musicphone.guide.page1..N */
public class GuideScreen extends Screen {

    private static final int PAGES = 8;
    private static final int W = 180, H = 230;

    private int left, top;
    private int page = 0;
    private Button prev, next;

    public GuideScreen() {
        super(Component.translatable("item.musicphone.phone_guide"));
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        prev = addRenderableWidget(Button.builder(Component.literal("<"), b -> setPage(page - 1))
                .bounds(left + 10, top + H - 28, 30, 20).build());
        next = addRenderableWidget(Button.builder(Component.literal(">"), b -> setPage(page + 1))
                .bounds(left + W - 40, top + H - 28, 30, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.done"), b -> onClose())
                .bounds(left + W / 2 - 30, top + H - 28, 60, 20).build());
        setPage(page);
    }

    private void setPage(int p) {
        page = Math.max(0, Math.min(PAGES - 1, p));
        prev.active = page > 0;
        next.active = page < PAGES - 1;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        g.fill(left, top, left + W, top + H, 0xFF7B5B2A);
        g.fill(left + 4, top + 4, left + W - 4, top + H - 4, 0xFFEBDDB0);

        g.drawCenteredString(font, Component.translatable("item.musicphone.phone_guide"), left + W / 2, top + 10, 0xFF5A3A12);
        g.drawCenteredString(font, Component.translatable("musicphone.guide.pageof", page + 1, PAGES),
                left + W / 2, top + 22, 0xFF8A6A32);

        List<FormattedCharSequence> lines = font.split(Component.translatable("musicphone.guide.page" + (page + 1)), W - 28);
        int y = top + 38;
        for (FormattedCharSequence line : lines) {
            g.drawString(font, line, left + 14, y, 0xFF2B1B0A, false);
            y += 10;
        }
        super.render(g, mx, my, pt);
    }
}
