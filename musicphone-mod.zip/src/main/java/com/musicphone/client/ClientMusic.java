package com.musicphone.client;

import com.musicphone.SongList;
import com.musicphone.item.PhoneItem;
import com.musicphone.net.StatePacket;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

import java.util.List;
import java.util.Random;

/**
 * قلب الهاتف عند اللاعب. The phone's brain on the client.
 *
 *  OFF     = الهاتف مطفأ (أو لا يوجد هاتف في الحقيبة)  / phone off (or no phone in inventory)
 *  IDLE    = مفعّل والخياران OFF -> لا شيء يشتغل        / on, both options OFF -> nothing plays
 *  PRIVATE = أغاني خاصة (يسمعها هذا اللاعب فقط)        / private songs
 *  SERVER  = أغاني السيرفر                            / server songs
 */
public final class ClientMusic {

    public enum Mode { OFF, IDLE, PRIVATE, SERVER }

    public static int serverCurrent = -1;
    public static int serverMode = 2;
    public static int privCurrent = -1;

    private static int serverSerial = -1;
    private static int privSerial = 0;
    private static int privTicksLeft = 0;

    private static boolean phoneInInventory = false;

    private static PhoneSound sound;
    private static Mode soundKind = Mode.OFF;
    private static int soundSerial = -1;

    private static final Random RNG = new Random();

    static {
        ClientSettings.load();
    }

    // ------------------------------------------------------------ الحالة

    /** حسب الإعدادات فقط. By settings only. */
    public static Mode settingsMode() {
        if (!ClientSettings.power) return Mode.OFF;
        if (ClientSettings.privateMusic) return Mode.PRIVATE;   // Private يلغي Server
        if (ClientSettings.server) return Mode.SERVER;
        return Mode.IDLE;
    }

    public static Mode effective() {
        return phoneInInventory ? settingsMode() : Mode.OFF;
    }

    public static boolean isPlaying() {
        return sound != null;
    }

    // ------------------------------------------------------------ أغاني السيرفر

    public static void onState(StatePacket p) {
        serverCurrent = p.current;
        serverMode = p.mode;
        serverSerial = p.serial;
        refresh();
    }

    // ------------------------------------------------------------ الأغاني الخاصة

    public static void privatePlay(int index) {
        if (index < 0 || index >= SongList.count(false)) return;
        privCurrent = index;
        privSerial++;
        privTicksLeft = SongList.ticks(false, index);
        refresh();
    }

    public static void privateStop() {
        privCurrent = -1;
        refresh();
    }

    private static void privateNext() {
        int n = SongList.count(false);
        int next;
        switch (ClientSettings.privMode) {
            case 0 -> next = privCurrent;
            case 1 -> {
                next = privCurrent;
                if (n > 1) { do { next = RNG.nextInt(n); } while (next == privCurrent); }
            }
            default -> next = (privCurrent + 1) % n;
        }
        privatePlay(next);
    }

    // ------------------------------------------------------------ التشغيل

    /** يقرر ماذا يجب أن يشتغل الآن. Decides what should be playing right now. */
    public static void refresh() {
        Mode m = effective();
        if (m != Mode.PRIVATE) privCurrent = -1;

        if (m == Mode.SERVER && serverCurrent >= 0) {
            if (sound == null || soundKind != Mode.SERVER || soundSerial != serverSerial) {
                startSound(Mode.SERVER, SongList.SERVER, serverCurrent, serverSerial);
            }
        } else if (m == Mode.PRIVATE && privCurrent >= 0) {
            if (sound == null || soundKind != Mode.PRIVATE || soundSerial != privSerial) {
                startSound(Mode.PRIVATE, SongList.PRIVATE, privCurrent, privSerial);
            }
        } else {
            stopSound();
        }
    }

    private static void startSound(Mode kind, List<String> ids, int index, int serial) {
        stopSound();
        if (index < 0 || index >= ids.size()) return;
        sound = new PhoneSound(ids.get(index), ClientSettings.volume);
        soundKind = kind;
        soundSerial = serial;
        Minecraft.getInstance().getSoundManager().play(sound);
    }

    private static void stopSound() {
        if (sound != null) {
            Minecraft.getInstance().getSoundManager().stop(sound);
            sound = null;
        }
        soundKind = Mode.OFF;
    }

    public static void setVolume(float v) {
        ClientSettings.volume = v;
        if (sound != null) sound.setVolume(v);
    }

    // ------------------------------------------------------------ كل تك

    public static void checkPhone() {
        Player p = Minecraft.getInstance().player;
        if (p == null) return;
        boolean has = false;
        for (ItemStack s : p.getInventory().items) if (s.getItem() instanceof PhoneItem) { has = true; break; }
        if (!has) for (ItemStack s : p.getInventory().offhand) if (s.getItem() instanceof PhoneItem) { has = true; break; }
        if (has != phoneInInventory) {
            phoneInInventory = has;
            refresh();
        }
    }

    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        if (mc.player.tickCount % 10 == 0) checkPhone();
        if (mc.isPaused()) return;
        if (effective() == Mode.PRIVATE && privCurrent >= 0 && --privTicksLeft <= 0) {
            privateNext();
        }
    }

    public static void reset() {
        stopSound();
        serverCurrent = -1;
        serverSerial = -1;
        privCurrent = -1;
        phoneInInventory = false;
    }

    private ClientMusic() {}
}
