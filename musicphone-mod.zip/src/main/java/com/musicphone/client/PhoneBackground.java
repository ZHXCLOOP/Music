package com.musicphone.client;

import com.mojang.blaze3d.platform.NativeImage;
import com.musicphone.MusicPhoneMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;

import java.io.InputStream;

/**
 * خلفية الهاتف: استبدل الملف التالي بصورتك (PNG).
 * Phone background: replace this file with your own PNG image:
 *   src/main/resources/assets/musicphone/textures/gui/phone_bg.png
 * أي حجم يصلح، تُقص من المنتصف بدون تشويه. Any size works, center-cropped without distortion.
 */
public final class PhoneBackground {

    private static final ResourceLocation TEX =
            new ResourceLocation(MusicPhoneMod.MOD_ID, "textures/gui/phone_bg.png");

    private static int texW = 1, texH = 1;

    /** يُستدعى عند فتح الواجهة. Called whenever the phone screen opens. */
    public static void load() {
        try (InputStream in = Minecraft.getInstance().getResourceManager().open(TEX);
             NativeImage img = NativeImage.read(in)) {
            texW = Math.max(1, img.getWidth());
            texH = Math.max(1, img.getHeight());
        } catch (Exception e) {
            texW = 1;
            texH = 1;
        }
    }

    public static void draw(GuiGraphics g, int x, int y, int w, int h) {
        float target = (float) w / (float) h;
        float image = (float) texW / (float) texH;
        int uW = texW, vH = texH, u = 0, v = 0;
        if (image > target) {
            uW = Math.round(texH * target);
            u = (texW - uW) / 2;
        } else {
            vH = Math.round(texW / target);
            v = (texH - vH) / 2;
        }
        g.blit(TEX, x, y, w, h, (float) u, (float) v, uW, vH, texW, texH);
    }

    private PhoneBackground() {}
}
