package com.musicphone.client;

import net.minecraftforge.fml.loading.FMLPaths;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** إعدادات اللاعب (تُحفظ في config/musicphone-client.properties). Per-player settings, saved to disk. */
public final class ClientSettings {

    public static boolean power = false;          // تنشيط الهاتف
    public static boolean server = false;         // Server Music
    public static boolean privateMusic = false;   // Private Music
    public static float volume = 1.0F;
    public static int privMode = 2;               // 0 تكرار، 1 عشوائي، 2 ترتيب

    private static boolean loaded = false;

    private static Path file() {
        return FMLPaths.CONFIGDIR.get().resolve("musicphone-client.properties");
    }

    public static synchronized void load() {
        if (loaded) return;
        loaded = true;
        try (InputStream in = Files.newInputStream(file())) {
            Properties p = new Properties();
            p.load(in);
            power = Boolean.parseBoolean(p.getProperty("power", "false"));
            server = Boolean.parseBoolean(p.getProperty("server", "false"));
            privateMusic = Boolean.parseBoolean(p.getProperty("private", "false"));
            volume = Math.max(0F, Math.min(1F, Float.parseFloat(p.getProperty("volume", "1.0"))));
            privMode = Math.max(0, Math.min(2, Integer.parseInt(p.getProperty("privMode", "2"))));
        } catch (Exception ignored) {
        }
    }

    public static synchronized void save() {
        Properties p = new Properties();
        p.setProperty("power", Boolean.toString(power));
        p.setProperty("server", Boolean.toString(server));
        p.setProperty("private", Boolean.toString(privateMusic));
        p.setProperty("volume", Float.toString(volume));
        p.setProperty("privMode", Integer.toString(privMode));
        try (OutputStream out = Files.newOutputStream(file())) {
            p.store(out, "Music Phone client settings");
        } catch (Exception ignored) {
        }
    }

    private ClientSettings() {}
}
