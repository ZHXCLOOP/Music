package com.musicphone.client;

import com.musicphone.MusicPhoneMod;
import net.minecraft.client.resources.sounds.AbstractSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;

/** صوت بدون مسافة: يسمعه اللاعب في أي مكان. Non-positional: audible anywhere, any distance. */
public class PhoneSound extends AbstractSoundInstance {

    public PhoneSound(String songId, float volume) {
        super(new ResourceLocation(MusicPhoneMod.MOD_ID, songId), SoundSource.RECORDS, SoundInstance.createUnseededRandom());
        this.volume = volume;
        this.pitch = 1.0F;
        this.looping = false;
        this.delay = 0;
        this.attenuation = SoundInstance.Attenuation.NONE;
        this.relative = true;
    }

    public void setVolume(float v) {
        this.volume = v;
    }

    public boolean canStartSilent() {
        return true;
    }
}
