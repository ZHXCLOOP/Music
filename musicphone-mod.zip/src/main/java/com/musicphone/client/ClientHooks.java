package com.musicphone.client;

import net.minecraft.client.Minecraft;

public final class ClientHooks {

    public static void openPhone(boolean admin) {
        Minecraft.getInstance().setScreen(new PhoneScreen(admin));
    }

    public static void openGuide() {
        Minecraft.getInstance().setScreen(new GuideScreen());
    }

    private ClientHooks() {}
}
