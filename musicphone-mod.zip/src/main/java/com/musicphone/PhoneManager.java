package com.musicphone;

import com.musicphone.item.ModItems;
import com.musicphone.net.ActionPacket;
import com.musicphone.net.Net;
import com.musicphone.net.StatePacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.PacketDistributor;

import java.util.Random;

/** حالة أغاني السيرفر. Server-music state (controlled only by admins). */
public final class PhoneManager {

    public static final int MODE_LOOP = 0, MODE_SHUFFLE = 1, MODE_ORDER = 2;

    private static final Random RNG = new Random();
    private static int current = -1;
    private static int mode = MODE_ORDER;
    private static int serial = 0;
    private static int ticksLeft = 0;

    public static void reset() {
        current = -1;
        mode = MODE_ORDER;
        ticksLeft = 0;
    }

    /** أدمن (OP) + يحمل الهاتف الإداري. OP + holds the Admin Phone. */
    public static boolean canControl(ServerPlayer p) {
        if (!p.hasPermissions(2)) return false;
        for (ItemStack s : p.getInventory().items) if (s.is(ModItems.ADMIN_PHONE.get())) return true;
        for (ItemStack s : p.getInventory().offhand) if (s.is(ModItems.ADMIN_PHONE.get())) return true;
        return false;
    }

    public static void handle(byte type, int value) {
        switch (type) {
            case ActionPacket.PLAY -> play(value);
            case ActionPacket.STOP -> { current = -1; broadcast(); }
            case ActionPacket.MODE -> {
                if (value >= 0 && value <= 2) { mode = value; broadcast(); }
            }
            default -> { }
        }
    }

    private static void play(int index) {
        if (index < 0 || index >= SongList.count(true)) return;
        current = index;
        ticksLeft = SongList.ticks(true, index);
        serial++;
        broadcast();
    }

    public static void tick() {
        if (current < 0) return;
        if (--ticksLeft > 0) return;
        int n = SongList.count(true);
        int next;
        switch (mode) {
            case MODE_LOOP -> next = current;
            case MODE_SHUFFLE -> {
                next = current;
                if (n > 1) { do { next = RNG.nextInt(n); } while (next == current); }
            }
            default -> next = (current + 1) % n;
        }
        play(next);
    }

    private static StatePacket state() {
        return new StatePacket(current, mode, serial);
    }

    private static void broadcast() {
        Net.CHANNEL.send(PacketDistributor.ALL.noArg(), state());
    }

    public static void sendTo(ServerPlayer player) {
        Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), state());
    }

    private PhoneManager() {}
}
