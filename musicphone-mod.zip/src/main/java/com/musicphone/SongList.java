package com.musicphone;

import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * قوائم الأغاني / Song lists
 *
 * PRIVATE = أغاني الهاتف الخاصة (يسمعها صاحبها فقط)  / private songs (only the player hears them)
 * SERVER  = أغاني السيرفر (يضبطها الأدمن ويسمعها من فعّل Server Music) / server songs (admin controls)
 *
 * الملفات / Files:
 *   assets/musicphone/sounds/private/<id>.ogg
 *   assets/musicphone/sounds/server/<id>.ogg
 *
 * المدة تُقرأ تلقائياً من الملف. الحد الأقصى 8 دقائق. تظهر أول 4 أغاني فقط في كل قائمة.
 * Duration is read automatically. Max 8 minutes. Only the first 4 songs of each list are shown.
 */
public final class SongList {

    public static final List<String> PRIVATE = List.of("private_one", "private_two", "private_three");
    public static final List<String> SERVER  = List.of("server_one", "server_two", "server_three");

    public static final int MAX_SHOWN = 4;
    public static final int MAX_SECONDS = 8 * 60;

    private static final Map<String, Integer> CACHE = new HashMap<>();

    public static List<String> list(boolean server) {
        return server ? SERVER : PRIVATE;
    }

    public static int count(boolean server) {
        return Math.min(list(server).size(), MAX_SHOWN);
    }

    public static synchronized int seconds(boolean server, int index) {
        String id = list(server).get(index);
        return CACHE.computeIfAbsent(id, k -> {
            String path = "/assets/" + MusicPhoneMod.MOD_ID + "/sounds/" + (server ? "server" : "private") + "/" + id + ".ogg";
            try (InputStream in = SongList.class.getResourceAsStream(path)) {
                if (in == null) throw new IllegalStateException("file not found: " + path);
                int sec = (int) Math.ceil(OggDuration.seconds(in.readAllBytes()));
                if (sec > MAX_SECONDS) {
                    System.err.println("[musicphone] " + id + ".ogg is " + sec + "s, longer than 8 minutes. It will be cut at 8:00.");
                    sec = MAX_SECONDS;
                }
                return Math.max(sec, 1);
            } catch (Exception e) {
                System.err.println("[musicphone] could not read duration of " + id + ": " + e);
                return MAX_SECONDS;
            }
        });
    }

    /** مدة الأغنية بالتكات + ثانية فاصل. */
    public static int ticks(boolean server, int index) {
        return seconds(server, index) * 20 + 20;
    }

    private SongList() {}
}
