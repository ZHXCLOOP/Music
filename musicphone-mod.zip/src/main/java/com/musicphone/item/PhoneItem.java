package com.musicphone.item;

import com.musicphone.client.ClientHooks;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;

public class PhoneItem extends Item {

    public final boolean admin;

    public PhoneItem(Properties properties, boolean admin) {
        super(properties);
        this.admin = admin;
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return admin;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) {
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.openPhone(admin));
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
