package com.musicphone.item;

import com.musicphone.MusicPhoneMod;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MusicPhoneMod.MOD_ID);

    /** الهاتف العادي (يُصنع) / regular phone (craftable) */
    public static final RegistryObject<Item> PHONE =
            ITEMS.register("music_phone", () -> new PhoneItem(new Item.Properties().stacksTo(1), false));

    /** الهاتف الإداري (بالأمر فقط) / admin phone (command only) */
    public static final RegistryObject<Item> ADMIN_PHONE =
            ITEMS.register("admin_phone", () -> new PhoneItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC), true));

    /** كتاب التعليمات / instruction book */
    public static final RegistryObject<Item> GUIDE =
            ITEMS.register("phone_guide", () -> new GuideItem(new Item.Properties().stacksTo(1)));

    private ModItems() {}
}
