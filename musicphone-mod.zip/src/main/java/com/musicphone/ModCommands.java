package com.musicphone;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.musicphone.item.ModItems;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

/**
 *  /musicphone admin  -> الهاتف الإداري (OP فقط) / Admin Phone (OP only)
 *  /musicphone guide  -> كتاب التعليمات (الجميع) / instruction book (everyone)
 */
public final class ModCommands {

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("musicphone")
                .then(Commands.literal("guide")
                        .executes(c -> give(c.getSource(), new ItemStack(ModItems.GUIDE.get()), "musicphone.command.guide")))
                .then(Commands.literal("admin")
                        .requires(s -> s.hasPermission(2))
                        .executes(c -> give(c.getSource(), new ItemStack(ModItems.ADMIN_PHONE.get()), "musicphone.command.admin"))));
    }

    private static int give(CommandSourceStack src, ItemStack stack, String messageKey) throws CommandSyntaxException {
        ServerPlayer player = src.getPlayerOrException();
        if (!player.getInventory().add(stack)) {
            player.drop(stack, false);
        }
        src.sendSuccess(() -> Component.translatable(messageKey), false);
        return 1;
    }

    private ModCommands() {}
}
