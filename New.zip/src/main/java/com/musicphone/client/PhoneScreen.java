package com.musicphone.client;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.systems.RenderSystem;
import com.musicphone.MusicPhoneMod;
import com.musicphone.SongList;
import com.musicphone.net.ActionPacket;
import com.musicphone.net.Net;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;

import java.io.InputStream;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;

/** واجهة الهاتف / The phone screen. */
public class PhoneScreen extends Screen {

    /** خلفية الهاتف - استبدل هذا الملف بصورتك / phone background - replace this file with your image */
    private static final ResourceLocation BG =
            new ResourceLocation(MusicPhoneMod.MOD_ID, "textures/gui/phone_bg.png");

    private static final ResourceLocation[] MODE_ICONS = {
            new ResourceLocation(MusicPhoneMod.MOD_ID, "textures/gui/icon_loop.png"),
            new ResourceLocation(MusicPhoneMod.MOD_ID, "textures/gui/icon_shuffle.png"),
            new ResourceLocation(MusicPhoneMod.MOD_ID, "textures/gui/icon_order.png")
    };
    private static final ResourceLocation STOP_ICON =
            new ResourceLocation(MusicPhoneMod.MOD_ID, "textures/gui/icon_stop.png");
    private static final String[] MODE_KEYS = {
            "musicphone.mode.loop", "musicphone.mode.shuffle", "musicphone.mode.order"
    };

    private static final int W = 140, H = 280;

    private final boolean adminItem;
    private int left, top, sx, sy, sw, sh, ix, iw;
    private int bgW = 1, bgH = 1;

    public PhoneScreen(boolean adminItem) {
        super(Component.translatable("musicphone.title"));
        this.adminItem = adminItem;
    }

    /** الأدمن الحقيقي: هاتف إداري + صلاحية OP (السيرفر يتحقق أيضاً). */
    private boolean canControlServer() {
        Minecraft mc = Minecraft.getInstance();
        return adminItem && mc.player != null && mc.player.hasPermissions(2);
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        sx = left + 5;
        sy = top + 16;
        sw = W - 10;
        sh = H - 26;
        ix = sx + 4;
        iw = sw - 8;
        readBackgroundSize();
        ClientMusic.checkPhone();

        // ----- الخيارات الثلاثة / the three switches
        addRenderableWidget(new Toggle(ix, sy + 32, iw, 18, "musicphone.toggle.power",
                () -> ClientSettings.power,
                () -> true,
                () -> true,
                () -> Component.translatable("musicphone.tip.power"),
                () -> ClientSettings.power = !ClientSettings.power));

        addRenderableWidget(new Toggle(ix, sy + 54, iw, 18, "musicphone.toggle.server",
                () -> ClientSettings.server,
                () -> ClientSettings.power && !ClientSettings.privateMusic,
                () -> ClientSettings.power,
                () -> !ClientSettings.power ? Component.translatable("musicphone.tip.need_power")
                        : ClientSettings.privateMusic ? Component.translatable("musicphone.tip.private_overrides")
                        : Component.translatable("musicphone.tip.server"),
                () -> ClientSettings.server = !ClientSettings.server));

        addRenderableWidget(new Toggle(ix, sy + 76, iw, 18, "musicphone.toggle.private",
                () -> ClientSettings.privateMusic,
                () -> ClientSettings.power,
                () -> ClientSettings.power,
                () -> !ClientSettings.power ? Component.translatable("musicphone.tip.need_power")
                        : Component.translatable("musicphone.tip.private"),
                () -> ClientSettings.privateMusic = !ClientSettings.privateMusic));

        ClientMusic.Mode mode = ClientMusic.settingsMode();
        if (mode != ClientMusic.Mode.PRIVATE && mode != ClientMusic.Mode.SERVER) return;

        // ----- الأغاني والتحكم / songs and controls
        final boolean serverView = mode == ClientMusic.Mode.SERVER;
        final boolean control = !serverView || canControlServer();

        int n = SongList.count(serverView);
        for (int i = 0; i < n; i++) {
            addRenderableWidget(new SongButton(i, serverView, control, ix, sy + 100 + i * 25, iw, 22));
        }

        addRenderableWidget(new VolumeSlider(ix, top + H - 60, iw, 18));

        int by = top + H - 36;
        for (int m = 0; m < 3; m++) {
            final int md = m;
            addRenderableWidget(new IconButton(ix + m * 24, by, 22, 22, MODE_ICONS[m],
                    Component.translatable(MODE_KEYS[m]), control,
                    () -> serverView ? ClientMusic.serverMode == md : ClientSettings.privMode == md,
                    () -> {
                        if (serverView) {
                            Net.CHANNEL.sendToServer(new ActionPacket(ActionPacket.MODE, md));
                        } else {
                            ClientSettings.privMode = md;
                            ClientSettings.save();
                        }
                    }));
        }
        addRenderableWidget(new IconButton(ix + iw - 22, by, 22, 22, STOP_ICON,
                Component.translatable("musicphone.stop"), control,
                () -> false,
                () -> {
                    if (serverView) Net.CHANNEL.sendToServer(new ActionPacket(ActionPacket.STOP, 0));
                    else ClientMusic.privateStop();
                }));
    }

    private void readBackgroundSize() {
        try (InputStream in = Minecraft.getInstance().getResourceManager().open(BG);
             NativeImage img = NativeImage.read(in)) {
            bgW = Math.max(1, img.getWidth());
            bgH = Math.max(1, img.getHeight());
        } catch (Exception e) {
            bgW = 1;
            bgH = 1;
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void removed() {
        ClientSettings.save();
    }

    /** تغيير خيار ثم إعادة بناء الواجهة. */
    private void apply(Runnable change) {
        change.run();
        ClientSettings.save();
        ClientMusic.refresh();
        clearWidgets();
        init();
    }

    // ---------------------------------------------------------------- الرسم

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);

        // جسم الهاتف / phone body
        g.fill(left, top, left + W, top + H, 0xFF0C0C10);
        g.fill(left, top, left + W, top + 1, 0xFF4A4A58);
        g.fill(left, top + H - 1, left + W, top + H, 0xFF4A4A58);
        g.fill(left, top, left + 1, top + H, 0xFF4A4A58);
        g.fill(left + W - 1, top, left + W, top + H, 0xFF4A4A58);
        g.fill(left + W / 2 - 14, top + 6, left + W / 2 + 14, top + 9, 0xFF2A2A34);
        g.fill(left + W / 2 - 18, top + H - 6, left + W / 2 + 18, top + H - 4, 0xFF3A3A46);

        // الخلفية: قص من المنتصف بدون تشويه / background: center-cropped
        float target = (float) sw / (float) sh;
        float image = (float) bgW / (float) bgH;
        int uW = bgW, vH = bgH, u = 0, v = 0;
        if (image > target) {
            uW = Math.round(bgH * target);
            u = (bgW - uW) / 2;
        } else {
            vH = Math.round(bgW / target);
            v = (bgH - vH) / 2;
        }
        RenderSystem.enableBlend();
        g.blit(BG, sx, sy, sw, sh, (float) u, (float) v, uW, vH, bgW, bgH);
        g.fill(sx, sy, sx + sw, sy + sh, 0x33000000);

        ClientMusic.Mode mode = ClientMusic.settingsMode();

        // العنوان والحالة / title and status
        int cx = left + W / 2;
        g.fill(sx + 4, sy + 4, sx + sw - 4, sy + 28, 0x99000000);
        Component title = adminItem ? Component.translatable("musicphone.title.admin") : this.title;
        g.drawCenteredString(font, title, cx, sy + 7, adminItem ? 0xFFD34A : 0xFFFFFF);
        g.drawCenteredString(font, font.plainSubstrByWidth(statusText(mode), sw - 16), cx, sy + 18, 0x9CE8FF);

        boolean showControls = mode == ClientMusic.Mode.PRIVATE || mode == ClientMusic.Mode.SERVER;
        if (showControls) {
            g.fill(sx + 4, top + H - 64, sx + sw - 4, top + H - 12, 0x99000000);
        } else {
            Component msg = Component.translatable(mode == ClientMusic.Mode.OFF ? "musicphone.msg.off" : "musicphone.msg.idle");
            List<FormattedCharSequence> lines = font.split(msg, iw - 12);
            g.fill(ix, sy + 102, ix + iw, sy + 110 + lines.size() * 10 + 4, 0x99000000);
            int y = sy + 108;
            for (FormattedCharSequence line : lines) {
                g.drawString(font, line, ix + 6, y, 0xFFFFFF);
                y += 10;
            }
        }

        super.render(g, mx, my, pt);

        for (var child : children()) {
            if (child instanceof TipWidget t && t.over(mx, my)) {
                Component tip = t.tip();
                if (tip != null) g.renderTooltip(font, font.split(tip, 160), mx, my);
            }
        }
    }

    private static Component songName(String id) {
        String key = "musicphone.song." + id;
        return I18n.exists(key) ? Component.translatable(key) : Component.literal(id);
    }

    private String statusText(ClientMusic.Mode mode) {
        switch (mode) {
            case OFF:
                return Component.translatable("musicphone.status.off").getString();
            case IDLE:
                return Component.translatable("musicphone.status.idle").getString();
            case PRIVATE:
                if (ClientMusic.privCurrent >= 0 && ClientMusic.privCurrent < SongList.PRIVATE.size()) {
                    return Component.translatable("musicphone.status.private",
                            songName(SongList.PRIVATE.get(ClientMusic.privCurrent))).getString();
                }
                return Component.translatable("musicphone.status.private_stopped").getString();
            default:
                if (ClientMusic.serverCurrent >= 0 && ClientMusic.serverCurrent < SongList.SERVER.size()) {
                    return Component.translatable("musicphone.status.server",
                            songName(SongList.SERVER.get(ClientMusic.serverCurrent))).getString();
                }
                return Component.translatable("musicphone.status.server_stopped").getString();
        }
    }

    private void box(GuiGraphics g, int x, int y, int w, int h, int bg, int border) {
        g.fill(x, y, x + w, y + h, bg);
        g.fill(x, y, x + w, y + 1, border);
        g.fill(x, y + h - 1, x + w, y + h, border);
        g.fill(x, y, x + 1, y + h, border);
        g.fill(x + w - 1, y, x + w, y + h, border);
    }

    // ---------------------------------------------------------------- الأزرار

    private abstract class TipWidget extends AbstractWidget {
        TipWidget(int x, int y, int w, int h) {
            super(x, y, w, h, Component.empty());
        }

        abstract Component tip();

        boolean over(int mx, int my) {
            return mx >= getX() && mx < getX() + getWidth() && my >= getY() && my < getY() + getHeight();
        }

        @Override
        public void updateWidgetNarration(NarrationElementOutput out) {
        }
    }

    /** مفتاح تشغيل/إيقاف. On/Off switch. */
    private class Toggle extends TipWidget {
        private final String labelKey;
        private final BooleanSupplier state, enabled;
        private final Supplier<Component> tip;
        private final Runnable change;

        Toggle(int x, int y, int w, int h, String labelKey, BooleanSupplier state, BooleanSupplier enabled,
               BooleanSupplier clickable, Supplier<Component> tip, Runnable change) {
            super(x, y, w, h);
            this.labelKey = labelKey;
            this.state = state;
            this.enabled = enabled;
            this.tip = tip;
            this.change = change;
            this.active = clickable.getAsBoolean();
        }

        @Override
        Component tip() {
            return tip.get();
        }

        @Override
        public void renderWidget(GuiGraphics g, int mx, int my, float pt) {
            boolean on = state.getAsBoolean();
            boolean dim = !enabled.getAsBoolean();
            int x = getX(), y = getY(), w = getWidth(), h = getHeight();
            int bg = dim ? 0x90000000 : (isHoveredOrFocused() ? 0xCC3A3A66 : 0xB0000000);
            int border = (on && !dim) ? 0xFF55FF88 : 0xFF555566;
            box(g, x, y, w, h, bg, border);
            int lamp = on ? (dim ? 0xFF2F7A47 : 0xFF3CFF7A) : (dim ? 0xFF6A2A2A : 0xFFFF4444);
            g.fill(x + 5, y + 6, x + 11, y + 12, lamp);
            int color = dim ? 0xFF8A8A8A : 0xFFFFFFFF;
            int ty = y + (h - 8) / 2;
            g.drawString(font, Component.translatable(labelKey), x + 16, ty, color);
            String s = Component.translatable(on ? "musicphone.on" : "musicphone.off").getString();
            g.drawString(font, s, x + w - 6 - font.width(s), ty, on && !dim ? 0xFF7CFFA0 : color);
        }

        @Override
        public void onClick(double mx, double my) {
            apply(change);
        }
    }

    private class SongButton extends TipWidget {
        private final int index;
        private final boolean server, control;

        SongButton(int index, boolean server, boolean control, int x, int y, int w, int h) {
            super(x, y, w, h);
            this.index = index;
            this.server = server;
            this.control = control;
            this.active = control;
        }

        @Override
        Component tip() {
            return control ? null : Component.translatable("musicphone.tip.locked");
        }

        @Override
        public void renderWidget(GuiGraphics g, int mx, int my, float pt) {
            int playing = server ? ClientMusic.serverCurrent : ClientMusic.privCurrent;
            boolean cur = playing == index;
            int bg = cur ? 0xCC1E6B3A : (!control ? 0x90000000 : (isHoveredOrFocused() ? 0xCC3A3A66 : 0xB0000000));
            int border = cur ? 0xFF55FF88 : (control && isHoveredOrFocused() ? 0xFFAAAAFF : 0xFF555566);
            box(g, getX(), getY(), getWidth(), getHeight(), bg, border);
            String text = (cur ? "> " : "") + songName(SongList.list(server).get(index)).getString();
            g.drawString(font, font.plainSubstrByWidth(text, getWidth() - 12), getX() + 7,
                    getY() + (getHeight() - 8) / 2, control ? 0xFFFFFF : 0xFF9A9A9A);
        }

        @Override
        public void onClick(double mx, double my) {
            if (server) Net.CHANNEL.sendToServer(new ActionPacket(ActionPacket.PLAY, index));
            else ClientMusic.privatePlay(index);
        }
    }

    private class IconButton extends TipWidget {
        private final ResourceLocation icon;
        private final Component name;
        private final BooleanSupplier selected;
        private final Runnable action;

        IconButton(int x, int y, int w, int h, ResourceLocation icon, Component name, boolean control,
                   BooleanSupplier selected, Runnable action) {
            super(x, y, w, h);
            this.icon = icon;
            this.name = name;
            this.selected = selected;
            this.action = action;
            this.active = control;
        }

        @Override
        Component tip() {
            return active ? name : Component.translatable("musicphone.tip.locked");
        }

        @Override
        public void renderWidget(GuiGraphics g, int mx, int my, float pt) {
            boolean sel = selected.getAsBoolean();
            int bg = sel ? 0xCC6B5A1E : (!active ? 0x90000000 : (isHoveredOrFocused() ? 0xCC3A3A66 : 0xB0000000));
            int border = sel ? 0xFFFFD34A : (active && isHoveredOrFocused() ? 0xFFAAAAFF : 0xFF555566);
            box(g, getX(), getY(), getWidth(), getHeight(), bg, border);
            if (sel) RenderSystem.setShaderColor(1.0F, 0.85F, 0.3F, 1.0F);
            else if (!active) RenderSystem.setShaderColor(0.5F, 0.5F, 0.5F, 1.0F);
            else RenderSystem.setShaderColor(0.85F, 0.85F, 0.9F, 1.0F);
            RenderSystem.enableBlend();
            g.blit(icon, getX() + (getWidth() - 16) / 2, getY() + (getHeight() - 16) / 2, 0, 0, 16, 16, 16, 16);
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        }

        @Override
        public void onClick(double mx, double my) {
            action.run();
        }
    }

    private static class VolumeSlider extends AbstractSliderButton {

        VolumeSlider(int x, int y, int w, int h) {
            super(x, y, w, h, Component.empty(), ClientSettings.volume);
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            setMessage(Component.translatable("musicphone.volume", (int) Math.round(value * 100.0)));
        }

        @Override
        protected void applyValue() {
            ClientMusic.setVolume((float) value);
        }
    }
}
