# Music Phone - Forge 1.20.1

## الأوامر / Commands (في الشات / in chat)
- `/musicphone admin`  -> الهاتف الإداري (OP فقط) / Admin Phone (OP only)
- `/musicphone guide`  -> كتاب التعليمات (الجميع) / instruction book (everyone)
في العالم الفردي لازم تكون الأوامر (Cheats) مفعّلة. In singleplayer, cheats must be ON.

## استبدال الأغاني / Replace songs  (استبدال مباشر بنفس الاسم / same file name)
أغاني خاصة / private:
  src/main/resources/assets/musicphone/sounds/private/private_one.ogg  (two, three)
أغاني السيرفر / server:
  src/main/resources/assets/musicphone/sounds/server/server_one.ogg    (two, three)
- لا تغيّر أي كود. المدة تُقرأ تلقائياً. الحد الأقصى 8 دقائق.
- اللاعبون كلهم لازم يكون عندهم نفس نسخة المود (الأغاني داخل الـ Jar).

## أسماء الأغاني / Song names
assets/musicphone/lang/en_us.json و ar_sa.json
المفتاح / key: musicphone.song.private_one

## خلفية الهاتف / Phone background
assets/musicphone/textures/gui/phone_bg.png
- PNG فقط، أي حجم، الأفضل 540x960، لا تتجاوز 2048 بكسل.

## تحويل الصوت / Convert audio
ffmpeg -i input.mp3 -c:a libvorbis -q:a 4 song.ogg

## إضافة أغنية رابعة / 4th song
1. ضع الملف في مجلد private أو server
2. أضف الاسم في SongList.java
3. أضف سطراً في sounds.json
(تظهر أول 4 أغاني فقط في كل قائمة)

## الوصفات / Recipes
- الهاتف: حديد x6 + لوح زجاج + ريدستون  (III / IGI / IRI)
- الكتاب: كتاب + ريدستون
- الهاتف الإداري: بالأمر فقط
